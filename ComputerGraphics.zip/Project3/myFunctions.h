void myFunction1(Mesh);
void myFunction2(Mesh);
void myFunction3(Mesh);
void generateEdges(Mesh m);
void myFunction4(Mesh);
void myFunction5(Mesh);
void myFunction6(Mesh);
void myFunctionS(Mesh);

void draw(Mesh);