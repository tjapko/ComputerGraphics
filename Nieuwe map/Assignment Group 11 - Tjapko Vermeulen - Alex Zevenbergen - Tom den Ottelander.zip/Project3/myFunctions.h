void myFunction1(Mesh);
void myFunction2(Mesh);
void myFunction3(Mesh);
void generateEdges(Mesh m);
void myFunction4(Mesh);
void myFunction5(Mesh);
void myFunction6(Mesh);
void myFunction7(Mesh);
void myFunction8(Mesh);
Mesh myFunction9(Mesh);
void myFunction0(Mesh);
Mesh myFunctionS(Mesh);
void myFunctionH();

void draw(Mesh);